package com.csse3200.game.components.hero;

import com.badlogic.gdx.Input;
import com.csse3200.game.components.Component;
import com.csse3200.game.entities.Entity;
import com.csse3200.game.entities.configs.HeroConfig;
import com.csse3200.game.entities.configs.HeroConfig2;
import com.csse3200.game.entities.configs.HeroConfig3;
import com.csse3200.game.components.hero.HeroTurretAttackComponent;
import com.csse3200.game.rendering.RotatingTextureRenderComponent;
import com.csse3200.game.services.ResourceService;
import com.csse3200.game.services.ServiceLocator;
import com.csse3200.game.input.InputComponent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;

/**
 * 一次性“英雄换肤”组件：
 * - 若地图上没有正式英雄（无 HeroTurretAttackComponent），则不响应任何按键；
 * - 若存在英雄，则按下 1/2/3 把该英雄的贴图切换到 HeroConfig/HeroConfig2/HeroConfig3 的 heroTexture；
 * - 成功切换一次后立即锁定并自我注销，后续不能再改。
 *
 * 使用方式：
 *   ServiceLocator.getEntityService().register(new Entity().addComponent(
 *       new HeroOneShotFormSwitchComponent(cfg1, cfg2, cfg3)
 *   ));
 */
public class HeroOneShotFormSwitchComponent extends InputComponent {
    private static final Logger logger = LoggerFactory.getLogger(HeroOneShotFormSwitchComponent.class);

    private final HeroConfig cfg1;   // 对应键 1
    private final HeroConfig2 cfg2;  // 对应键 2
    private final HeroConfig3 cfg3;  // 对应键 3

    private Entity hero;            // 已找到的“正式英雄”实体（非幽灵）
    private boolean locked = false; // 已切换并锁定

    public HeroOneShotFormSwitchComponent(HeroConfig cfg1, HeroConfig2 cfg2, HeroConfig3 cfg3) {
        // 高优先级，尽量拿到 1/2/3
        super(1000);
        this.cfg1 = cfg1;
        this.cfg2 = cfg2;
        this.cfg3 = cfg3;
    }

    @Override
    public void create() {
        super.create();
        // 预加载三套贴图（防止切换时资源未就绪）
        ResourceService rs = ServiceLocator.getResourceService();
        rs.loadTextures(new String[]{
                cfg1 != null ? cfg1.heroTexture : null,
                cfg2 != null ? cfg2.heroTexture : null,
                cfg3 != null ? cfg3.heroTexture : null
        });
        // 非阻塞等待（短时间轮询直到完成）；也可以跳过这段，依赖于全局预加载
        while (!rs.loadForMillis(5)) { /* spin a little */ }

        // 尝试找到地图上的“正式英雄”（幽灵没有 HeroTurretAttackComponent）
        for (Entity e : ServiceLocator.getEntityService().getEntities()) {
            if (e.getComponent(HeroTurretAttackComponent.class) != null) {
                hero = e;
                break;
            }
        }
        if (hero == null) {
            logger.info("[HeroSkinSwitch] No real hero found on map. Component will stay idle.");
        } else {
            logger.info("[HeroSkinSwitch] Found hero entity. Press 1/2/3 to switch skin once.");
        }
    }

    @Override
    public boolean keyDown(int keycode) {
        if (locked || hero == null) return false;

        if (keycode == Input.Keys.NUM_1 || keycode == Input.Keys.NUMPAD_1) {
            return switchOnce(cfg1 != null ? cfg1.heroTexture : null, "1");
        } else if (keycode == Input.Keys.NUM_2 || keycode == Input.Keys.NUMPAD_2) {
            return switchOnce(cfg2 != null ? cfg2.heroTexture : null, "2");
        } else if (keycode == Input.Keys.NUM_3 || keycode == Input.Keys.NUMPAD_3) {
            return switchOnce(cfg3 != null ? cfg3.heroTexture : null, "3");
        }
        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        if (locked || hero == null) return false;
        if (character == '1') return switchOnce(cfg1 != null ? cfg1.heroTexture : null, "1");
        if (character == '2') return switchOnce(cfg2 != null ? cfg2.heroTexture : null, "2");
        if (character == '3') return switchOnce(cfg3 != null ? cfg3.heroTexture : null, "3");
        return false;
    }

    private boolean switchOnce(String texturePath, String keyTag) {
        if (texturePath == null || texturePath.isBlank()) {
            logger.warn("[HeroSkinSwitch] Texture path for key {} is empty. Ignored.", keyTag);
            return false;
        }
        boolean ok = applyTextureToHero(texturePath);
        if (ok) {
            locked = true;
            logger.info("[HeroSkinSwitch] Applied texture via key {} -> {}. Locked.", keyTag, texturePath);
            // 切换成功后，立即注销自身（一次性）
            this.entity.dispose();
        }
        return ok;
    }

    /**
     * 尝试把英雄的渲染换成给定贴图。
     * 优先尝试在 RotatingTextureRenderComponent 上调用 setTexture(String)；
     * 若无此方法，可按你引擎的 API 需求扩展（例如替换组件等）。
     */
    private boolean applyTextureToHero(String texturePath) {
        try {
            RotatingTextureRenderComponent rot =
                    hero.getComponent(RotatingTextureRenderComponent.class);
            if (rot == null) {
                logger.warn("[HeroSkinSwitch] Hero has no RotatingTextureRenderComponent. Cannot switch.");
                return false;
            }

            // 反射尝试调用常见的设贴图方法：setTexture(String)
            Method m = null;
            try {
                m = rot.getClass().getMethod("setTexture", String.class);
            } catch (NoSuchMethodException ignore) {
                // 你的 RotatingTextureRenderComponent 若没有 setTexture，可在这里换成你项目里的实际 API
                // 比如 setTextureRegion / setPath / setSprite 等。没有就提示并返回 false。
            }
            if (m != null) {
                m.invoke(rot, texturePath);
                return true;
            } else {
                logger.error("[HeroSkinSwitch] RotatingTextureRenderComponent has no setTexture(String). " +
                        "Please add an API or extend this method to fit your engine.");
                return false;
            }
        } catch (Exception e) {
            logger.error("[HeroSkinSwitch] Failed to switch texture to {}: {}", texturePath, e.getMessage());
            return false;
        }
    }
}
